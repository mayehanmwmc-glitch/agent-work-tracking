import { useState, useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { cn } from './utils/cn';

interface Customer {
  id: string;
  name: string;
  age: number;
  email: string;
  phone: string;
  salary: number;
  noc: number; // Number of Cases/Policies
  monthlyPremium: number;
  lifeCoverage: number;
  criticalIllness: number;
  accidentCoverage: number;
  medicalLimit: number;
  lastContact: string;
  nextFollowUp: string;
  status: 'Prospect' | 'Active' | 'Follow-up' | 'Inactive';
  notes: string;
}

const initialCustomers: Customer[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    age: 34,
    email: 'sarah.chen@email.com',
    phone: '(555) 123-4567',
    salary: 95000,
    noc: 3,
    monthlyPremium: 245,
    lifeCoverage: 500000,
    criticalIllness: 250000,
    accidentCoverage: 100000,
    medicalLimit: 15000,
    lastContact: '2025-12-10',
    nextFollowUp: '2026-01-15',
    status: 'Active',
    notes: 'Renewal due in March. Interested in increasing life coverage.'
  },
  {
    id: '2',
    name: 'Michael Rodriguez',
    age: 42,
    email: 'mike.r@email.com',
    phone: '(555) 234-5678',
    salary: 125000,
    noc: 2,
    monthlyPremium: 380,
    lifeCoverage: 750000,
    criticalIllness: 400000,
    accidentCoverage: 250000,
    medicalLimit: 25000,
    lastContact: '2025-11-28',
    nextFollowUp: '2026-01-05',
    status: 'Follow-up',
    notes: 'Family added to policy last year.'
  },
  {
    id: '3',
    name: 'Priya Patel',
    age: 29,
    email: 'priya.patel@work.com',
    phone: '(555) 345-6789',
    salary: 68000,
    noc: 1,
    monthlyPremium: 135,
    lifeCoverage: 300000,
    criticalIllness: 150000,
    accidentCoverage: 50000,
    medicalLimit: 10000,
    lastContact: '2025-12-20',
    nextFollowUp: '2026-02-01',
    status: 'Prospect',
    notes: 'New lead from seminar.'
  },
  {
    id: '4',
    name: 'David Kim',
    age: 51,
    email: 'dkim55@gmail.com',
    phone: '(555) 456-7890',
    salary: 165000,
    noc: 4,
    monthlyPremium: 520,
    lifeCoverage: 1200000,
    criticalIllness: 500000,
    accidentCoverage: 300000,
    medicalLimit: 30000,
    lastContact: '2025-12-05',
    nextFollowUp: '2026-01-20',
    status: 'Active',
    notes: 'High net worth client. Review investment linked products.'
  },
  {
    id: '5',
    name: 'Emma Thompson',
    age: 27,
    email: 'emma.t@email.com',
    phone: '(555) 567-8901',
    salary: 52000,
    noc: 2,
    monthlyPremium: 89,
    lifeCoverage: 200000,
    criticalIllness: 100000,
    accidentCoverage: 75000,
    medicalLimit: 8000,
    lastContact: '2026-01-02',
    nextFollowUp: '2026-01-25',
    status: 'Active',
    notes: ''
  },
];

const statusColors = {
  'Prospect': 'bg-amber-100 text-amber-700',
  'Active': 'bg-emerald-100 text-emerald-700',
  'Follow-up': 'bg-rose-100 text-rose-700',
  'Inactive': 'bg-slate-100 text-slate-700',
};

const ageGroups = [
  { name: '18-30', min: 18, max: 30 },
  { name: '31-45', min: 31, max: 45 },
  { name: '46-60', min: 46, max: 60 },
  { name: '60+', min: 61, max: 100 },
];

export default function App() {
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'customers' | 'analytics' | 'followups'>('dashboard');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'name' | 'age' | 'premium'>('name');

  const [formData, setFormData] = useState<Partial<Customer>>({
    name: '',
    age: 30,
    email: '',
    phone: '',
    salary: 60000,
    noc: 1,
    monthlyPremium: 150,
    lifeCoverage: 250000,
    criticalIllness: 100000,
    accidentCoverage: 50000,
    medicalLimit: 10000,
    lastContact: new Date().toISOString().split('T')[0],
    nextFollowUp: '',
    status: 'Prospect',
    notes: '',
  });

  const addOrUpdateCustomer = () => {
    if (!formData.name || !formData.age || !formData.email) return;

    const newCustomer: Customer = {
      id: editingCustomer ? editingCustomer.id : Date.now().toString(),
      name: formData.name as string,
      age: formData.age as number,
      email: formData.email as string,
      phone: formData.phone || '',
      salary: formData.salary || 50000,
      noc: formData.noc || 1,
      monthlyPremium: formData.monthlyPremium || 100,
      lifeCoverage: formData.lifeCoverage || 200000,
      criticalIllness: formData.criticalIllness || 100000,
      accidentCoverage: formData.accidentCoverage || 50000,
      medicalLimit: formData.medicalLimit || 10000,
      lastContact: formData.lastContact || new Date().toISOString().split('T')[0],
      nextFollowUp: formData.nextFollowUp || '',
      status: (formData.status as any) || 'Prospect',
      notes: formData.notes || '',
    };

    if (editingCustomer) {
      setCustomers(customers.map(c => c.id === editingCustomer.id ? newCustomer : c));
    } else {
      setCustomers([...customers, newCustomer]);
    }

    closeModal();
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingCustomer(null);
    setFormData({
      name: '', age: 30, email: '', phone: '', salary: 60000, noc: 1,
      monthlyPremium: 150, lifeCoverage: 250000, criticalIllness: 100000,
      accidentCoverage: 50000, medicalLimit: 10000,
      lastContact: new Date().toISOString().split('T')[0],
      nextFollowUp: '',
      status: 'Prospect',
      notes: '',
    });
  };

  const editCustomer = (customer: Customer) => {
    setEditingCustomer(customer);
    setFormData({...customer});
    setIsModalOpen(true);
  };

  const deleteCustomer = (id: string) => {
    if (confirm('Delete this customer?')) {
      setCustomers(customers.filter(c => c.id !== id));
    }
  };

  // Filtered and sorted customers
  const filteredCustomers = useMemo(() => {
    let result = customers.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           c.email.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === 'All' || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });

    result.sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'age') return a.age - b.age;
      return (b.monthlyPremium || 0) - (a.monthlyPremium || 0);
    });

    return result;
  }, [customers, searchTerm, statusFilter, sortBy]);

  // Dashboard stats
  const totalCustomers = customers.length;
  const totalMonthlyPremium = customers.reduce((sum, c) => sum + (c.monthlyPremium || 0), 0);
  const avgAge = totalCustomers > 0 ? Math.round(customers.reduce((sum, c) => sum + c.age, 0) / totalCustomers) : 0;
  const pendingFollowUps = customers.filter(c => {
    if (!c.nextFollowUp) return false;
    const followDate = new Date(c.nextFollowUp);
    const today = new Date();
    const diffTime = followDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 3600 * 24));
    return diffDays > 0 && diffDays <= 14;
  }).length;

  const totalAnnualPremium = totalMonthlyPremium * 12;

  // Analytics data
  const ageDistribution = useMemo(() => {
    return ageGroups.map(group => {
      const count = customers.filter(c => c.age >= group.min && c.age <= group.max).length;
      const totalPremium = customers
        .filter(c => c.age >= group.min && c.age <= group.max)
        .reduce((sum, c) => sum + c.monthlyPremium, 0);
      return {
        name: group.name,
        count: count,
        premium: Math.round(totalPremium),
      };
    });
  }, [customers]);

  const statusDistribution = useMemo(() => {
    const statusCount = customers.reduce((acc, c) => {
      acc[c.status] = (acc[c.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const colors = ['#3b82f6', '#10b981', '#f59e0b', '#6b7280'];
    const statuses = Object.keys(statusCount);
    
    return statuses.map((status, index) => ({
      name: status,
      value: statusCount[status],
      color: colors[index % colors.length]
    }));
  }, [customers]);

  const premiumByAge = ageDistribution;

  const upcomingFollowups = useMemo(() => {
    return [...customers]
      .filter(c => c.nextFollowUp)
      .sort((a, b) => new Date(a.nextFollowUp).getTime() - new Date(b.nextFollowUp).getTime())
      .slice(0, 8);
  }, [customers]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatLargeNumber = (num: number) => {
    if (num >= 1000000) return '$' + (num/1000000).toFixed(1) + 'M';
    if (num >= 1000) return '$' + (num/1000).toFixed(0) + 'k';
    return '$' + num;
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <div className="w-72 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-6 border-b border-slate-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-bold text-2xl">C</div>
            <div>
              <div className="font-semibold text-2xl tracking-tighter text-slate-900">CoverFlow</div>
              <div className="text-[10px] text-slate-400 -mt-1">INSURANCE CRM</div>
            </div>
          </div>
        </div>

        <div className="p-3 flex-1 overflow-y-auto">
          <nav className="space-y-1">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
              { id: 'customers', label: 'Customers', icon: '👥' },
              { id: 'analytics', label: 'Analytics', icon: '📊' },
              { id: 'followups', label: 'Follow-ups', icon: '📅' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id as any)}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 text-left rounded-2xl transition-all",
                  currentTab === tab.id 
                    ? "bg-indigo-50 text-indigo-700 shadow-sm font-medium" 
                    : "hover:bg-slate-100 text-slate-600"
                )}
              >
                <span className="text-xl">{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>

          <div className="mt-10 px-4">
            <div className="text-xs font-medium text-slate-400 mb-3 px-3">QUICK STATS</div>
            <div className="bg-slate-50 rounded-3xl p-4 text-sm">
              <div className="flex justify-between py-2 border-b">
                <div className="text-slate-500">Total Clients</div>
                <div className="font-semibold">{totalCustomers}</div>
              </div>
              <div className="flex justify-between py-2 border-b">
                <div className="text-slate-500">Monthly Premium</div>
                <div className="font-semibold text-emerald-600">{formatCurrency(totalMonthlyPremium)}</div>
              </div>
              <div className="flex justify-between py-2">
                <div className="text-slate-500">Avg Age</div>
                <div className="font-semibold">{avgAge}</div>
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 border-t mt-auto">
          <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-2xl">
            <div className="w-9 h-9 bg-violet-200 rounded-full flex items-center justify-center text-violet-600 text-sm font-medium">JA</div>
            <div className="text-sm">
              <div className="font-medium">James Anderson</div>
              <div className="text-slate-500 text-xs">Senior Agent</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="h-16 border-b bg-white px-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-2xl font-semibold text-slate-800 capitalize">{currentTab}</h1>
            {currentTab === 'customers' && (
              <button 
                onClick={() => setIsModalOpen(true)}
                className="ml-4 flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium px-5 h-9 rounded-2xl transition-all active:scale-[0.985]"
              >
                <span className="text-lg leading-none">+</span> 
                <span>New Customer</span>
              </button>
            )}
          </div>
          
          <div className="flex items-center gap-6 text-sm">
            <div className="flex items-center gap-2 bg-emerald-100 text-emerald-700 px-3 py-1 rounded-3xl text-xs font-medium">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
              ONLINE
            </div>
            <div className="text-slate-400">Jan 10, 2026</div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-auto p-8">
          {currentTab === 'dashboard' && (
            <div className="max-w-screen-2xl mx-auto space-y-8">
              {/* KPI Cards */}
              <div className="grid grid-cols-4 gap-6">
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-slate-500 text-sm">Total Customers</div>
                      <div className="text-5xl font-semibold mt-3 text-slate-900">{totalCustomers}</div>
                    </div>
                    <div className="text-4xl">👥</div>
                  </div>
                  <div className="mt-6 text-emerald-600 text-sm flex items-center gap-1">
                    +4 this month
                  </div>
                </div>
                
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-slate-500 text-sm">Annual Premium</div>
                      <div className="text-5xl font-semibold mt-3 text-slate-900">{formatLargeNumber(totalAnnualPremium)}</div>
                    </div>
                    <div className="text-4xl">💰</div>
                  </div>
                  <div className="mt-6 text-emerald-600 text-sm flex items-center gap-1">
                    ↑12% from last quarter
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-slate-500 text-sm">Avg Age</div>
                      <div className="text-5xl font-semibold mt-3 text-slate-900">{avgAge}</div>
                    </div>
                    <div className="text-4xl">📅</div>
                  </div>
                  <div className="mt-6 text-amber-600 text-sm flex items-center gap-1">
                    Balanced portfolio
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 relative overflow-hidden">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="text-slate-500 text-sm">Pending Follow-ups</div>
                      <div className="text-5xl font-semibold mt-3 text-rose-600">{pendingFollowUps}</div>
                    </div>
                    <div className="text-4xl">📌</div>
                  </div>
                  <div className="absolute bottom-6 right-6 text-[70px] opacity-10">⏰</div>
                </div>
              </div>

              <div className="grid grid-cols-12 gap-6">
                {/* Age Distribution */}
                <div className="col-span-7 bg-white rounded-3xl p-7 shadow-sm border">
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <div className="font-semibold">Age Group Distribution</div>
                      <div className="text-sm text-slate-500">Customers by age brackets</div>
                    </div>
                  </div>
                  <ResponsiveContainer width="100%" height={260}>
                    <BarChart data={ageDistribution}>
                      <CartesianGrid strokeDasharray="2 2" stroke="#f1f5f9" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#4f46e5" radius={6} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Status Breakdown */}
                <div className="col-span-5 bg-white rounded-3xl p-7 shadow-sm border">
                  <div className="font-semibold mb-6">Customer Status</div>
                  <div className="flex justify-center">
                    <ResponsiveContainer width="100%" height={240}>
                      <PieChart>
                        <Pie
                          data={statusDistribution}
                          cx="50%"
                          cy="50%"
                          innerRadius={65}
                          outerRadius={95}
                          dataKey="value"
                        >
                          {statusDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="grid grid-cols-2 gap-3 mt-4 text-sm">
                    {statusDistribution.map((entry, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{backgroundColor: entry.color}}></div>
                        <div>{entry.name}: <span className="font-medium">{entry.value}</span></div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent Customers */}
                <div className="col-span-12 bg-white rounded-3xl shadow-sm border p-7">
                  <div className="flex items-center justify-between mb-6">
                    <div className="font-semibold">Recent Customers</div>
                    <button onClick={() => setCurrentTab('customers')} className="text-indigo-600 text-sm flex items-center gap-1 hover:underline">
                      View all →
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-5 gap-4">
                    {customers.slice(0, 5).map((cust, idx) => (
                      <div key={idx} onClick={() => editCustomer(cust)} className="bg-slate-50 hover:bg-white p-5 rounded-3xl cursor-pointer border border-transparent hover:border-slate-200 transition-all">
                        <div className="font-medium text-base">{cust.name}</div>
                        <div className="text-xs text-slate-500 mt-0.5">{cust.age} • {cust.email.split('@')[0]}</div>
                        
                        <div className="mt-6 flex items-baseline gap-1">
                          <span className="text-3xl font-semibold text-emerald-600">{formatCurrency(cust.monthlyPremium)}</span>
                          <span className="text-xs text-slate-400">/mo</span>
                        </div>
                        
                        <div className={`inline-block mt-4 text-[10px] px-3 py-px rounded-3xl font-medium ${statusColors[cust.status]}`}>
                          {cust.status}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentTab === 'customers' && (
            <div className="max-w-screen-2xl mx-auto">
              <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                {/* Filters */}
                <div className="p-6 border-b flex items-center gap-4">
                  <input
                    type="text"
                    placeholder="Search customers..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex-1 bg-slate-100 border-0 focus:ring-1 h-11 rounded-2xl px-5 text-sm placeholder:text-slate-400"
                  />
                  
                  <select 
                    value={statusFilter} 
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="bg-slate-100 border-0 h-11 rounded-2xl px-5 text-sm focus:ring-1"
                  >
                    <option value="All">All Status</option>
                    <option value="Prospect">Prospect</option>
                    <option value="Active">Active</option>
                    <option value="Follow-up">Follow-up</option>
                    <option value="Inactive">Inactive</option>
                  </select>

                  <select 
                    value={sortBy} 
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="bg-slate-100 border-0 h-11 rounded-2xl px-5 text-sm focus:ring-1"
                  >
                    <option value="name">Sort: Name</option>
                    <option value="age">Sort: Age</option>
                    <option value="premium">Sort: Premium</option>
                  </select>
                </div>

                {/* Table */}
                <div className="overflow-auto max-h-[calc(100vh-260px)]">
                  <table className="w-full">
                    <thead className="bg-slate-50 sticky top-0 z-10">
                      <tr className="border-b">
                        <th className="text-left py-5 px-8 font-medium text-xs text-slate-500">CUSTOMER</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">AGE</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">INCOME</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">NOC</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">PREMIUM</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">LIFE COV.</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">STATUS</th>
                        <th className="text-left py-5 px-4 font-medium text-xs text-slate-500">NEXT FOLLOW-UP</th>
                        <th className="w-28"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {filteredCustomers.map((customer) => (
                        <tr key={customer.id} className="hover:bg-slate-50 transition-colors group">
                          <td className="py-5 px-8">
                            <div className="font-medium">{customer.name}</div>
                            <div className="text-xs text-slate-400">{customer.email}</div>
                          </td>
                          <td className="py-5 px-4 text-slate-600 font-medium">{customer.age}</td>
                          <td className="py-5 px-4 text-slate-600">{formatCurrency(customer.salary)}</td>
                          <td className="py-5 px-4 font-medium text-slate-700">{customer.noc}</td>
                          <td className="py-5 px-4">
                            <div className="font-semibold text-emerald-600">{formatCurrency(customer.monthlyPremium)}</div>
                          </td>
                          <td className="py-5 px-4 text-slate-600 font-mono text-sm">
                            {formatLargeNumber(customer.lifeCoverage)}
                          </td>
                          <td className="py-5 px-4">
                            <span className={`inline-block px-4 py-1 text-xs font-medium rounded-3xl ${statusColors[customer.status]}`}>
                              {customer.status}
                            </span>
                          </td>
                          <td className="py-5 px-4 text-xs font-medium text-slate-500">
                            {customer.nextFollowUp ? new Date(customer.nextFollowUp).toLocaleDateString('en-US', {month:'short', day:'numeric'}) : '—'}
                          </td>
                          <td className="py-5 px-4">
                            <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-all">
                              <button onClick={() => editCustomer(customer)} className="text-indigo-600 hover:text-indigo-800 px-3 py-1 text-xs border border-slate-200 hover:border-indigo-200 rounded-2xl">Edit</button>
                              <button onClick={() => deleteCustomer(customer.id)} className="text-rose-400 hover:text-rose-600 px-3 py-1 text-xs border border-slate-200 hover:border-rose-200 rounded-2xl">Delete</button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                {filteredCustomers.length === 0 && (
                  <div className="py-20 text-center text-slate-400">No customers found.</div>
                )}
              </div>
            </div>
          )}

          {currentTab === 'analytics' && (
            <div className="max-w-screen-2xl mx-auto space-y-8">
              <div className="grid grid-cols-2 gap-6">
                {/* Age vs Premium */}
                <div className="bg-white p-7 rounded-3xl border shadow-sm">
                  <div className="font-semibold mb-2">Age Group Premiums</div>
                  <div className="text-xs text-slate-500 mb-6">Monthly premium contribution by age</div>
                  <ResponsiveContainer width="100%" height={320}>
                    <BarChart data={premiumByAge}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value}`, 'Monthly Premium']} />
                      <Bar dataKey="premium" fill="#22c55e" radius={[6,6,0,0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                {/* Coverage Mix */}
                <div className="bg-white p-7 rounded-3xl border shadow-sm">
                  <div className="font-semibold mb-6">Average Coverage Breakdown</div>
                  
                  <div className="space-y-8 pt-4">
                    {[
                      { label: "Life Coverage", avg: Math.round(customers.reduce((s, c) => s + c.lifeCoverage, 0) / (customers.length || 1)), color: '#6366f1' },
                      { label: "Critical Illness", avg: Math.round(customers.reduce((s, c) => s + c.criticalIllness, 0) / (customers.length || 1)), color: '#ec4899' },
                      { label: "Accident", avg: Math.round(customers.reduce((s, c) => s + c.accidentCoverage, 0) / (customers.length || 1)), color: '#eab308' },
                      { label: "Medical Limit", avg: Math.round(customers.reduce((s, c) => s + c.medicalLimit, 0) / (customers.length || 1)), color: '#14b8a6' },
                    ].map((item, index) => (
                      <div key={index}>
                        <div className="flex justify-between text-sm mb-3">
                          <div>{item.label}</div>
                          <div className="font-medium">{formatLargeNumber(item.avg)}</div>
                        </div>
                        <div className="h-2.5 bg-slate-100 rounded-3xl overflow-hidden">
                          <div 
                            className="h-2.5 rounded-3xl" 
                            style={{ 
                              width: `${Math.min(100, Math.max(15, (item.avg / 1200000) * 100))}%`,
                              backgroundColor: item.color 
                            }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-3xl p-8 border">
                <h3 className="font-semibold mb-5">Portfolio Summary</h3>
                <div className="grid grid-cols-3 gap-5">
                  <div className="border rounded-3xl p-6">
                    <div className="uppercase text-xs text-slate-400 tracking-widest">TOTAL LIFE COVERAGE</div>
                    <div className="text-5xl font-semibold text-slate-800 mt-4">{formatLargeNumber(customers.reduce((sum, c) => sum + c.lifeCoverage, 0))}</div>
                  </div>
                  <div className="border rounded-3xl p-6">
                    <div className="uppercase text-xs text-slate-400 tracking-widest">TOTAL MEDICAL LIMITS</div>
                    <div className="text-5xl font-semibold text-teal-600 mt-4">{formatLargeNumber(customers.reduce((sum, c) => sum + c.medicalLimit, 0))}</div>
                  </div>
                  <div className="border rounded-3xl p-6">
                    <div className="uppercase text-xs text-slate-400 tracking-widest">AVG NOC</div>
                    <div className="text-5xl font-semibold text-slate-800 mt-4">{(customers.reduce((sum, c) => sum + c.noc, 0) / (customers.length || 1)).toFixed(1)}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentTab === 'followups' && (
            <div className="max-w-4xl mx-auto">
              <div className="bg-white rounded-3xl p-8 border">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <div className="text-xl font-semibold">Upcoming Follow-ups</div>
                    <div className="text-slate-500">Next 30 days • {upcomingFollowups.length} customers need attention</div>
                  </div>
                  <div className="px-5 py-2 bg-rose-50 text-rose-600 text-xs font-medium rounded-3xl">PRIORITY</div>
                </div>

                <div className="space-y-3">
                  {upcomingFollowups.map(customer => {
                    const daysLeft = Math.ceil((new Date(customer.nextFollowUp).getTime() - new Date().getTime()) / (1000*3600*24));
                    return (
                      <div key={customer.id} className="flex items-center justify-between bg-slate-50 hover:bg-white border border-transparent hover:border-slate-200 p-5 rounded-3xl transition-all group">
                        <div className="flex items-center gap-5">
                          <div>
                            <div className="font-semibold text-lg leading-none">{customer.name}</div>
                            <div className="text-xs text-slate-500 mt-2 flex gap-4">
                              <span>{customer.age} years old</span>
                              <span className="font-mono">{formatCurrency(customer.monthlyPremium)}/mo</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className={`text-xs font-medium inline-block px-4 py-1 rounded-3xl mb-2 ${daysLeft <= 7 ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-700'}`}>
                            {daysLeft} days
                          </div>
                          <div className="text-xs text-slate-500">Follow up on {new Date(customer.nextFollowUp).toLocaleDateString()}</div>
                        </div>
                        
                        <button 
                          onClick={() => editCustomer(customer)}
                          className="ml-8 px-8 py-3 text-sm font-medium bg-white border border-slate-300 hover:bg-indigo-50 hover:border-indigo-300 rounded-2xl transition-colors"
                        >
                          Contact
                        </button>
                      </div>
                    );
                  })}
                  
                  {upcomingFollowups.length === 0 && (
                    <div className="text-center py-12 text-slate-400">No upcoming follow-ups. Great job!</div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50" onClick={closeModal}>
          <div 
            className="bg-white w-full max-w-2xl mx-4 rounded-3xl shadow-2xl overflow-hidden"
            onClick={e => e.stopPropagation()}
          >
            <div className="px-8 pt-8 pb-2">
              <div className="flex justify-between items-center">
                <div className="text-2xl font-semibold">
                  {editingCustomer ? 'Edit Customer' : 'Add New Customer'}
                </div>
                <button onClick={closeModal} className="text-3xl text-slate-300 hover:text-slate-400">×</button>
              </div>
            </div>

            <div className="p-8 pt-2 grid grid-cols-2 gap-x-8 gap-y-6">
              <div className="col-span-2">
                <label className="block text-xs font-medium text-slate-500 mb-1.5">FULL NAME</label>
                <input 
                  value={formData.name || ''} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3 text-lg placeholder:text-slate-300"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">AGE</label>
                <input 
                  type="number" 
                  value={formData.age || ''} 
                  onChange={(e) => setFormData({...formData, age: parseInt(e.target.value) || 0})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">STATUS</label>
                <select 
                  value={formData.status} 
                  onChange={(e) => setFormData({...formData, status: e.target.value as any})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3 bg-white"
                >
                  <option value="Prospect">Prospect</option>
                  <option value="Active">Active</option>
                  <option value="Follow-up">Follow-up</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">EMAIL</label>
                <input 
                  type="email" 
                  value={formData.email || ''} 
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">PHONE</label>
                <input 
                  value={formData.phone || ''} 
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">ANNUAL SALARY</label>
                <input 
                  type="number" 
                  value={formData.salary || ''} 
                  onChange={(e) => setFormData({...formData, salary: parseInt(e.target.value) || 0})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">NO. OF CASES (NOC)</label>
                <input 
                  type="number" 
                  value={formData.noc || ''} 
                  onChange={(e) => setFormData({...formData, noc: parseInt(e.target.value) || 0})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">MONTHLY PREMIUM ($)</label>
                <input 
                  type="number" 
                  value={formData.monthlyPremium || ''} 
                  onChange={(e) => setFormData({...formData, monthlyPremium: parseInt(e.target.value) || 0})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>

              <div className="col-span-2 border-t pt-6 mt-3">
                <div className="uppercase text-xs tracking-widest text-slate-400 mb-4">COVERAGE DETAILS</div>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">LIFE COVERAGE</label>
                    <input 
                      type="number" 
                      value={formData.lifeCoverage || ''} 
                      onChange={(e) => setFormData({...formData, lifeCoverage: parseInt(e.target.value) || 0})}
                      className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">CRITICAL ILLNESS</label>
                    <input 
                      type="number" 
                      value={formData.criticalIllness || ''} 
                      onChange={(e) => setFormData({...formData, criticalIllness: parseInt(e.target.value) || 0})}
                      className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">ACCIDENT COVERAGE</label>
                    <input 
                      type="number" 
                      value={formData.accidentCoverage || ''} 
                      onChange={(e) => setFormData({...formData, accidentCoverage: parseInt(e.target.value) || 0})}
                      className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-500 mb-1.5">MEDICAL CARD LIMIT</label>
                    <input 
                      type="number" 
                      value={formData.medicalLimit || ''} 
                      onChange={(e) => setFormData({...formData, medicalLimit: parseInt(e.target.value) || 0})}
                      className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">LAST CONTACT</label>
                <input 
                  type="date" 
                  value={formData.lastContact || ''} 
                  onChange={(e) => setFormData({...formData, lastContact: e.target.value})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-1.5">NEXT FOLLOW UP</label>
                <input 
                  type="date" 
                  value={formData.nextFollowUp || ''} 
                  onChange={(e) => setFormData({...formData, nextFollowUp: e.target.value})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-2xl px-5 py-3"
                />
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-medium text-slate-500 mb-1.5">NOTES</label>
                <textarea 
                  value={formData.notes || ''} 
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  className="w-full border border-slate-200 focus:border-indigo-300 rounded-3xl px-5 py-3 h-20 resize-y"
                  placeholder="Additional notes, preferences..."
                ></textarea>
              </div>
            </div>

            <div className="bg-slate-50 px-8 py-6 flex gap-3 justify-end border-t">
              <button 
                onClick={closeModal}
                className="px-8 py-3.5 text-slate-500 hover:bg-slate-100 rounded-2xl font-medium"
              >
                Cancel
              </button>
              <button 
                onClick={addOrUpdateCustomer}
                className="bg-indigo-600 hover:bg-indigo-700 transition-colors text-white px-10 py-3.5 rounded-2xl font-medium shadow-inner"
              >
                {editingCustomer ? 'Save Changes' : 'Add Customer'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
